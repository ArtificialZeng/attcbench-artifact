# ATTCBench local artifact release — review staging

This is a local, unpublished review package assembled from the existing ICDE9 artifact. It contains the original `artifact9/` tree, the existing Makefile, per-file hashes, and packaging provenance. No experiment was run and no result was regenerated during packaging.

## Layout and entry points

Extract the ZIP into an empty directory. The release root contains `Makefile` beside `artifact9/`. Run all commands from that root, not from inside `artifact9/`.

- `make` or `make artifact`: generate the seeded trace, characterize it, replay the dry-run adapter, aggregate results, and write `artifact9.zip`.
- `python3 -m pip install -r artifact9/requirements-real.txt`, followed by `make real-subset`: run the existing DuckDB and FAISS native subtrace adapters and the fanout sweep.
- `make fanout-sweep`: run the existing DuckDB/FAISS fanout values 1, 2, 4, and 8.

These are instructions for subsequent review; they were not executed during staging. Python 3.9+, make, and zip are needed. The native subset additionally uses the supplied requirements: duckdb==1.4.4, faiss-cpu==1.13.0, numpy>=1.25,<3.

The only Makefile change is a prepended `.DEFAULT_GOAL := artifact` setting so that plain `make` selects the artifact target. The rest is byte-identical to the original. `provenance/Makefile.original` preserves the original file; both hashes are in MANIFEST.json. The inherited `paper`, `clean`, and explicit `all` targets concern the omitted manuscript and are not artifact entry points; they require manuscript files and a LaTeX installation.

## Supplied scope

The existing material includes a deterministic trace generator, trace schema, replay/analysis/characterization scripts, seed and sweep traces, raw JSONL logs, summaries, optional native requirements, and a target-system manifest. `artifact9/README.md` is retained unchanged.

The dry-run adapter validates generation/replay/accounting and does not establish DBMS performance. The native adapters cover DuckDB relational records and FAISS vector records only. The target-system list is not an implementation list: PostgreSQL, Spark SQL, Milvus, pgvector, Flink, and Materialize have no native adapter in this supplied scaffold. This package does not add adapters, measurements, container recipes, or external datasets.

## Integrity and publication state

MANIFEST.json lists original sources, per-file SHA256 values, the packaging-only change, and syntax-only checks. SHA256SUMS covers all package files except itself. The existing files were copied unchanged. The original archive remains separately preserved in the staging area's original_archives directory.

This is a candidate for author review, not evidence of public availability. No public URL, license, or hosting account is invented by this package.
