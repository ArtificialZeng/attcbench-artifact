# ATTCBench Trace Schema

Each trace is JSON Lines. One line is one data operation.

Required fields:

- `op_id`: unique operation id.
- `episode_id`: user-level reasoning episode.
- `branch_id`: branch path identifier.
- `parent_id`: parent operation id or `null`.
- `issue_ms`: scheduled issue time in milliseconds.
- `modality`: `relational`, `vector`, or `stream`.
- `semantic_key`: benchmark-visible evidence intent.
- `query_hash`: normalized system-visible operation hash.
- `reuse_group`: group id for offline reuse attribution.
- `template`: operation template name.
- `payload`: modality-specific request payload.

The benchmark uses `semantic_key` and `reuse_group` only for offline
attribution unless an explicit oracle-sharing experiment is configured.
