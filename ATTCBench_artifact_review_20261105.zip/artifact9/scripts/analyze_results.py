#!/usr/bin/env python3
"""Aggregate ATTCBench raw result logs."""

import argparse
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path


def percentile(values: list[float], pct: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = min(len(ordered) - 1, int(round((pct / 100.0) * (len(ordered) - 1))))
    return ordered[idx]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    args = parser.parse_args()

    rows = []
    with Path(args.input).open("r", encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                rows.append(json.loads(line))

    latencies = [row["latency_ms"] for row in rows]
    by_modality = defaultdict(list)
    for row in rows:
        by_modality[row["modality"]].append(row["latency_ms"])

    exact_hits = sum(1 for row in rows if row["exact_cache_hit"])
    semantic_seen = sum(1 for row in rows if row["semantic_reuse_seen"])
    episodes = {row["episode_id"] for row in rows}
    modalities = Counter(row["modality"] for row in rows)
    systems = Counter(row["system"] for row in rows)

    by_episode = defaultdict(list)
    by_episode_branch = defaultdict(list)
    for row in rows:
        by_episode[row["episode_id"]].append(row)
        by_episode_branch[(row["episode_id"], row["branch_id"])].append(row)

    episode_durations = []
    for episode_rows in by_episode.values():
        first_issue = min(row["scheduled_issue_ms"] for row in episode_rows)
        last_completion = max(row.get("completion_ms", row["scheduled_issue_ms"] + row["latency_ms"]) for row in episode_rows)
        episode_durations.append(last_completion - first_issue)

    branch_durations_by_episode = defaultdict(list)
    for (episode_id, _branch_id), branch_rows in by_episode_branch.items():
        first_issue = min(row["scheduled_issue_ms"] for row in branch_rows)
        last_completion = max(row.get("completion_ms", row["scheduled_issue_ms"] + row["latency_ms"]) for row in branch_rows)
        branch_durations_by_episode[episode_id].append(last_completion - first_issue)

    branch_straggler_ratios = []
    for durations in branch_durations_by_episode.values():
        if len(durations) > 1:
            median = percentile(durations, 50)
            if median > 0:
                branch_straggler_ratios.append(max(durations) / median)

    if rows:
        first_issue = min(row["scheduled_issue_ms"] for row in rows)
        last_completion = max(row.get("completion_ms", row["scheduled_issue_ms"] + row["latency_ms"]) for row in rows)
        elapsed_s = max((last_completion - first_issue) / 1000.0, 1e-9)
    else:
        elapsed_s = 0.0

    summary = {
        "ops": len(rows),
        "episodes": len(episodes),
        "resource_amplification": round(len(rows) / max(1, len(episodes)), 4),
        "latency_p50_ms": round(percentile(latencies, 50), 4),
        "latency_p95_ms": round(percentile(latencies, 95), 4),
        "latency_p99_ms": round(percentile(latencies, 99), 4),
        "latency_mean_ms": round(statistics.mean(latencies), 4) if latencies else 0,
        "episode_p50_ms": round(percentile(episode_durations, 50), 4),
        "episode_p95_ms": round(percentile(episode_durations, 95), 4),
        "episode_p99_ms": round(percentile(episode_durations, 99), 4),
        "branch_straggler_p95": round(percentile(branch_straggler_ratios, 95), 4),
        "throughput_ops_s": round(len(rows) / elapsed_s, 4) if elapsed_s else 0,
        "exact_cache_hit_rate": round(exact_hits / max(1, len(rows)), 4),
        "semantic_reuse_seen_rate": round(semantic_seen / max(1, len(rows)), 4),
        "modalities": dict(modalities),
        "systems": dict(systems),
        "by_modality_p99_ms": {k: round(percentile(v, 99), 4) for k, v in by_modality.items()},
    }
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
