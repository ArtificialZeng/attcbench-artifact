#!/usr/bin/env python3
"""Replay an ATTCBench trace and write raw per-operation results."""

import argparse
import hashlib
import json
import random
import statistics
import time
from collections import defaultdict
from pathlib import Path


SUPPORTED_SYSTEMS = [
    "dryrun",
    "duckdb",
    "postgresql",
    "spark_sql",
    "faiss",
    "milvus",
    "pgvector",
    "flink",
    "materialize",
]

DRYRUN_FACTORS = {"relational": 1.0, "vector": 1.2, "stream": 0.9}
NATIVE_MODALITY = {"duckdb": "relational", "faiss": "vector"}
TOPICS = [
    "orders",
    "incidents",
    "inventory",
    "customers",
    "tickets",
    "metrics",
    "contracts",
    "shipments",
]
REGIONS = ["NA", "EU", "APAC"]


def load_trace(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as fh:
        return [json.loads(line) for line in fh if line.strip()]


def reuse_flags(records: list[dict]) -> dict[str, tuple[bool, bool]]:
    seen_query: set[str] = set()
    seen_semantic: set[str] = set()
    flags = {}
    for record in records:
        query_hash = record["query_hash"]
        semantic_key = record["semantic_key"]
        flags[record["op_id"]] = (query_hash in seen_query, semantic_key in seen_semantic)
        seen_query.add(query_hash)
        seen_semantic.add(semantic_key)
    return flags


def common_record(record: dict, system: str, latency_ms: float, exact_hit: bool, semantic_seen: bool, **extra: object) -> dict:
    output = {
        "op_id": record["op_id"],
        "episode_id": record["episode_id"],
        "branch_id": record["branch_id"],
        "modality": record["modality"],
        "system": system,
        "scheduled_issue_ms": record["issue_ms"],
        "latency_ms": round(latency_ms, 4),
        "completion_ms": round(record["issue_ms"] + latency_ms, 4),
        "exact_cache_hit": exact_hit,
        "semantic_reuse_seen": semantic_seen,
        "reuse_group": record["reuse_group"],
        "query_hash": record["query_hash"],
    }
    output.update(extra)
    return output


def simulate(records: list[dict], system: str, seed: int) -> list[dict]:
    rng = random.Random(seed)
    group_counts = defaultdict(int)
    output = []
    flags = reuse_flags(records)

    for record in records:
        modality = record["modality"]
        reuse_group = record["reuse_group"]
        group_counts[reuse_group] += 1
        exact_hit, semantic_seen = flags[record["op_id"]]

        base = {"relational": 9.0, "vector": 6.0, "stream": 4.0}[modality]
        latency = base * DRYRUN_FACTORS[modality] * rng.lognormvariate(0.0, 0.25)
        if exact_hit:
            latency *= 0.45
        elif semantic_seen:
            latency *= 0.85

        output.append(common_record(record, system, latency, exact_hit, semantic_seen, rows_returned=0))
    return output


def topic_case(expr: str = "i") -> str:
    cases = " ".join(f"WHEN {idx} THEN '{topic}'" for idx, topic in enumerate(TOPICS))
    return f"CASE ({expr} % {len(TOPICS)}) {cases} END"


def region_case(expr: str = "i") -> str:
    cases = " ".join(f"WHEN {idx} THEN '{region}'" for idx, region in enumerate(REGIONS))
    return f"CASE ({expr} % {len(REGIONS)}) {cases} END"


def run_duckdb(records: list[dict], seed: int) -> list[dict]:
    try:
        import duckdb
    except ImportError as exc:
        raise SystemExit("DuckDB adapter requires `pip install duckdb`.") from exc

    con = duckdb.connect(database=":memory:")
    con.execute("PRAGMA threads=1")
    con.execute(
        f"""
        CREATE TABLE dim AS
        SELECT
          i::INTEGER AS id,
          {topic_case("i")} AS topic,
          CASE (i % 4)
            WHEN 0 THEN 'new'
            WHEN 1 THEN 'open'
            WHEN 2 THEN 'closed'
            ELSE 'review'
          END AS status,
          ((i * 37) % 100)::INTEGER AS score,
          {region_case("i")} AS region
        FROM range(0, 10000) t(i)
        """
    )
    con.execute(
        f"""
        CREATE TABLE fact AS
        SELECT
          (i % 10000)::INTEGER AS id,
          {topic_case("i")} AS topic,
          ((i % 60) + 1)::INTEGER AS day,
          (((i * 131) % 100000) / 100.0)::DOUBLE AS amount
        FROM range(0, 100000) t(i)
        """
    )
    con.execute("CREATE INDEX dim_topic_idx ON dim(topic)")
    con.execute("CREATE INDEX fact_topic_day_idx ON fact(topic, day)")

    native = [record for record in records if record["modality"] == "relational"]
    flags = reuse_flags(native)
    output = []
    for record in native:
        sql = record["payload"]["sql"]
        translated_sql = sql.replace("fact join dim using (id) where topic", "fact join dim using (id) where fact.topic")
        start = time.perf_counter()
        result = con.execute(translated_sql).fetchall()
        latency_ms = (time.perf_counter() - start) * 1000.0
        exact_hit, semantic_seen = flags[record["op_id"]]
        output.append(
            common_record(
                record,
                "duckdb",
                latency_ms,
                exact_hit,
                semantic_seen,
                rows_returned=len(result),
                translated_request=translated_sql,
                adapter_scope="native-relational-subtrace",
                dataset_rows={"fact": 100000, "dim": 10000},
                seed=seed,
            )
        )
    return output


def query_vector(text: str, dim: int) -> object:
    import numpy as np

    digest = hashlib.sha1(text.encode("utf-8")).digest()
    seed = int.from_bytes(digest[:8], "little", signed=False)
    rng = np.random.default_rng(seed)
    vec = rng.normal(size=dim).astype("float32")
    norm = np.linalg.norm(vec)
    return vec / norm if norm else vec


def run_faiss(records: list[dict], seed: int) -> list[dict]:
    try:
        import faiss
        import numpy as np
    except ImportError as exc:
        raise SystemExit("FAISS adapter requires `pip install faiss-cpu numpy`.") from exc

    dim = 64
    corpus_size = 20000
    rng = np.random.default_rng(seed)
    xb = rng.normal(size=(corpus_size, dim)).astype("float32")
    xb /= np.linalg.norm(xb, axis=1, keepdims=True)
    index = faiss.IndexFlatL2(dim)
    index.add(xb)

    native = [record for record in records if record["modality"] == "vector"]
    flags = reuse_flags(native)
    output = []
    for record in native:
        payload = record["payload"]
        q = query_vector(payload["query"], dim).reshape(1, dim)
        topk = int(payload["topk"])
        start = time.perf_counter()
        distances, ids = index.search(q, topk)
        latency_ms = (time.perf_counter() - start) * 1000.0
        exact_hit, semantic_seen = flags[record["op_id"]]
        output.append(
            common_record(
                record,
                "faiss",
                latency_ms,
                exact_hit,
                semantic_seen,
                rows_returned=len(ids[0]),
                translated_request={"query": payload["query"], "topk": topk, "index": "IndexFlatL2"},
                adapter_scope="native-vector-subtrace",
                dataset_rows={"vectors": corpus_size, "dimension": dim},
                seed=seed,
            )
        )
    return output


def run_system(records: list[dict], system: str, seed: int) -> list[dict]:
    if system == "dryrun":
        return simulate(records, system, seed)
    if system == "duckdb":
        return run_duckdb(records, seed)
    if system == "faiss":
        return run_faiss(records, seed)
    raise SystemExit(
        f"Adapter for {system} is not implemented in the local scaffold. "
        "Add a production adapter or service deployment before reporting system measurements."
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trace", required=True)
    parser.add_argument("--system", choices=SUPPORTED_SYSTEMS, default="dryrun")
    parser.add_argument("--out", required=True)
    parser.add_argument("--seed", type=int, default=9)
    args = parser.parse_args()

    records = load_trace(Path(args.trace))
    results = run_system(records, args.system, args.seed)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as fh:
        for result in results:
            fh.write(json.dumps(result, sort_keys=True) + "\n")

    latencies = [r["latency_ms"] for r in results]
    print(
        json.dumps(
            {
                "system": args.system,
                "ops": len(results),
                "latency_mean_ms": round(statistics.mean(latencies), 4) if latencies else 0,
                "out": str(out),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
