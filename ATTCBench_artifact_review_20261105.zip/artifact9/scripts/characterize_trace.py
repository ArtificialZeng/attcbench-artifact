#!/usr/bin/env python3
"""Characterize an ATTCBench trace before system replay."""

import argparse
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path


def percentile(values: list[float], pct: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = min(len(ordered) - 1, int(round((pct / 100.0) * (len(ordered) - 1))))
    return ordered[idx]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trace", required=True)
    args = parser.parse_args()

    rows = [json.loads(line) for line in Path(args.trace).read_text(encoding="utf-8").splitlines() if line.strip()]
    by_id = {row["op_id"]: row for row in rows}
    by_episode = defaultdict(list)
    children = defaultdict(list)
    semantic_groups = defaultdict(list)
    modality_transitions = Counter()
    depths = []

    for row in rows:
        by_episode[row["episode_id"]].append(row)
        semantic_groups[row["semantic_key"]].append(row)
        if row["parent_id"] is not None:
            children[row["parent_id"]].append(row["op_id"])
            modality_transitions[f"{by_id[row['parent_id']]['modality']}->{row['modality']}"] += 1

        depth = 0
        parent_id = row["parent_id"]
        while parent_id is not None:
            parent_id = by_id[parent_id]["parent_id"]
            depth += 1
        depths.append(depth)

    fanouts = [len(child_ids) for child_ids in children.values()]
    fragments = []
    exact_hits = 0
    semantic_seen = 0
    seen_query = set()
    seen_semantic = set()
    for row in rows:
        exact_hits += int(row["query_hash"] in seen_query)
        semantic_seen += int(row["semantic_key"] in seen_semantic)
        seen_query.add(row["query_hash"])
        seen_semantic.add(row["semantic_key"])

    for group_rows in semantic_groups.values():
        counts = Counter(row["query_hash"] for row in group_rows)
        fragments.append(1.0 - max(counts.values()) / len(group_rows))

    summary = {
        "trace": args.trace,
        "ops": len(rows),
        "episodes": len(by_episode),
        "ops_per_episode_mean": round(len(rows) / max(1, len(by_episode)), 4),
        "modalities": dict(Counter(row["modality"] for row in rows)),
        "fanout_mean": round(statistics.mean(fanouts), 4) if fanouts else 0,
        "fanout_p95": round(percentile(fanouts, 95), 4),
        "fanout_max": max(fanouts) if fanouts else 0,
        "depth_mean": round(statistics.mean(depths), 4) if depths else 0,
        "depth_max": max(depths) if depths else 0,
        "semantic_groups": len(semantic_groups),
        "semantic_group_size_mean": round(statistics.mean(len(rows) for rows in semantic_groups.values()), 4)
        if semantic_groups
        else 0,
        "cache_fragmentation_mean": round(statistics.mean(fragments), 4) if fragments else 0,
        "exact_cache_hit_rate": round(exact_hits / max(1, len(rows)), 4),
        "semantic_reuse_seen_rate": round(semantic_seen / max(1, len(rows)), 4),
        "parent_modality_transitions": dict(modality_transitions),
    }
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
