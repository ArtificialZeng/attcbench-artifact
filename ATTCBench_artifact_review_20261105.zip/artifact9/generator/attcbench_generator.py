#!/usr/bin/env python3
"""Generate deterministic agentic TTC benchmark traces."""

import argparse
import hashlib
import json
import random
from pathlib import Path


TOPICS = [
    "orders",
    "incidents",
    "inventory",
    "customers",
    "tickets",
    "metrics",
    "contracts",
    "shipments",
]

SQL_TEMPLATES = [
    "select sum(amount) from fact where topic = '{topic}' and day between {lo} and {hi}",
    "select id, status from dim where topic = '{topic}' and score >= {score}",
    "select count(*) from fact join dim using (id) where topic = '{topic}' and region = '{region}'",
]

VECTOR_TEMPLATES = [
    "evidence about {topic} risk {variant}",
    "documents similar to {topic} anomaly {variant}",
    "prior cases for {topic} decision {variant}",
]

STREAM_TEMPLATES = [
    "window:{topic}:5m",
    "window:{topic}:30m",
    "alerts:{topic}:latest",
]


def stable_hash(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]


def choose_modality(rng: random.Random, mix: str) -> str:
    weights = {
        "balanced": [0.4, 0.4, 0.2],
        "sql-heavy": [0.7, 0.2, 0.1],
        "vector-heavy": [0.2, 0.7, 0.1],
        "stream-heavy": [0.25, 0.25, 0.5],
    }[mix]
    return rng.choices(["relational", "vector", "stream"], weights=weights, k=1)[0]


def make_payload(rng: random.Random, modality: str, topic: str, variant: int) -> tuple[str, dict]:
    if modality == "relational":
        template = rng.choice(SQL_TEMPLATES)
        sql = template.format(
            topic=topic,
            lo=rng.randint(1, 20),
            hi=rng.randint(21, 60),
            score=rng.randint(10, 95),
            region=rng.choice(["NA", "EU", "APAC"]),
        )
        return "sql_template", {"sql": sql}
    if modality == "vector":
        template = rng.choice(VECTOR_TEMPLATES)
        query = template.format(topic=topic, variant=variant)
        return "vector_topk", {"query": query, "topk": rng.choice([5, 10, 20])}
    template = rng.choice(STREAM_TEMPLATES)
    return "stream_window", {"subscription": template.format(topic=topic), "limit": rng.choice([10, 50, 100])}


def generate(args: argparse.Namespace) -> list[dict]:
    rng = random.Random(args.seed)
    records: list[dict] = []
    op_counter = 0

    for episode in range(args.episodes):
        root_topic = rng.choice(TOPICS)
        episode_start = int(episode * args.episode_gap_ms)
        frontier = [(None, "b0", root_topic, 0, episode_start)]
        for depth in range(args.depth):
            next_frontier = []
            for parent_id, branch_id, topic, variant, base_time in frontier:
                branches = 1 if depth == 0 else max(1, int(rng.expovariate(1.0 / args.fanout)))
                branches = min(branches, args.fanout * 2)
                for branch_num in range(branches):
                    reuse = rng.random() < args.redundancy
                    drift = rng.random() < args.drift
                    next_topic = topic if reuse else rng.choice(TOPICS)
                    next_variant = variant if reuse else variant + 1
                    if drift:
                        next_variant += 1
                    modality = choose_modality(rng, args.mix)
                    template, payload = make_payload(rng, modality, next_topic, next_variant)
                    semantic_key = f"{next_topic}:intent:{variant if reuse else next_variant}"
                    payload_text = json.dumps(payload, sort_keys=True)
                    query_hash = stable_hash(f"{modality}:{template}:{payload_text}")
                    reuse_group = stable_hash(f"{episode}:{semantic_key}")
                    op_id = f"e{episode}_op{op_counter}"
                    burst_gap = int(rng.expovariate(1.0 / max(1, args.mean_gap_ms)))
                    issue_ms = base_time + min(burst_gap, args.max_gap_ms)
                    child_branch = f"{branch_id}.{branch_num}"
                    records.append(
                        {
                            "op_id": op_id,
                            "episode_id": f"episode_{episode}",
                            "branch_id": child_branch,
                            "parent_id": parent_id,
                            "issue_ms": issue_ms,
                            "modality": modality,
                            "semantic_key": semantic_key,
                            "query_hash": query_hash,
                            "reuse_group": reuse_group,
                            "template": template,
                            "payload": payload,
                        }
                    )
                    op_counter += 1
                    next_frontier.append((op_id, child_branch, next_topic, next_variant, issue_ms))
            frontier = next_frontier

    records.sort(key=lambda r: (r["issue_ms"], r["op_id"]))
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=9)
    parser.add_argument("--episodes", type=int, default=32)
    parser.add_argument("--depth", type=int, default=4)
    parser.add_argument("--fanout", type=int, default=4)
    parser.add_argument("--redundancy", type=float, default=0.5)
    parser.add_argument("--drift", type=float, default=0.25)
    parser.add_argument("--mix", choices=["balanced", "sql-heavy", "vector-heavy", "stream-heavy"], default="balanced")
    parser.add_argument("--episode-gap-ms", type=int, default=500)
    parser.add_argument("--mean-gap-ms", type=int, default=20)
    parser.add_argument("--max-gap-ms", type=int, default=250)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    records = generate(args)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as fh:
        for record in records:
            fh.write(json.dumps(record, sort_keys=True) + "\n")
    print(json.dumps({"out": str(out), "records": len(records), "seed": args.seed}, sort_keys=True))


if __name__ == "__main__":
    main()
