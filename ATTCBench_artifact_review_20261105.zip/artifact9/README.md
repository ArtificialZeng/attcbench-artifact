# ATTCBench Artifact Scaffold

This directory is the local reproducibility artifact for `paper9.tex`.
It is intentionally dependency-light so reviewers can validate trace generation
and metric computation before installing the full system matrix.

## Contents

- `generator/attcbench_generator.py`: deterministic trace generator.
- `traces/schema.md`: JSONL trace schema.
- `scripts/run_benchmark.py`: replay harness with a `dryrun` adapter.
- `scripts/characterize_trace.py`: pre-replay trace characterizer.
- `scripts/analyze_results.py`: aggregation script for raw JSONL results.
- `config/systems.json`: target system manifest.
- `results/raw/`: raw per-operation outputs.

## Quick Start

```bash
python3 artifact9/generator/attcbench_generator.py \
  --seed 9 --episodes 32 --fanout 4 --redundancy 0.5 \
  --out artifact9/traces/seed9.jsonl

python3 artifact9/scripts/characterize_trace.py \
  --trace artifact9/traces/seed9.jsonl

python3 artifact9/scripts/run_benchmark.py \
  --trace artifact9/traces/seed9.jsonl --system dryrun \
  --out artifact9/results/raw/dryrun_seed9.jsonl

python3 artifact9/scripts/analyze_results.py \
  --input artifact9/results/raw/dryrun_seed9.jsonl
```

The `dryrun` adapter does not claim DBMS measurements. It validates replay,
timing, reuse-group accounting, and metric aggregation. Production submissions
must add versioned adapters or container recipes for DuckDB, PostgreSQL,
Spark SQL, FAISS, Milvus, pgvector, Flink, and Materialize, then publish the
raw result logs and configuration files.

## Optional Local Real-System Subset

The scaffold also contains two dependency-light native adapters used by the
paper's local evaluation subset:

- `duckdb`: executes only relational trace records against an in-memory DuckDB
  database with deterministic `fact` and `dim` tables.
- `faiss`: executes only vector trace records against a deterministic
  FAISS `IndexFlatL2` corpus.

Install the optional dependencies and run:

```bash
python3 -m pip install -r artifact9/requirements-real.txt
make real-subset
```

The resulting files are:

- `results/raw/duckdb_seed9.jsonl`
- `results/summary_duckdb_seed9.json`
- `results/raw/faiss_seed9.jsonl`
- `results/summary_faiss_seed9.json`
- `results/raw/{duckdb,faiss}_seed9_fanout{1,2,4,8}.jsonl`
- `results/summary_{duckdb,faiss}_seed9_fanout{1,2,4,8}.json`

These are native subtrace measurements, not a nine-system campaign. Systems
without local adapters or running services are intentionally reported as not
measured.
